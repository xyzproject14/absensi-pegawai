<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/my_style.css') ?>">
    <title>ADMIN AKADEMIK</title>
    <style>
        .myblue {
            background-color: rgb(206, 212, 255);
        }
    </style>
</head>

<body>
    <div class="logo">
        <a href="<?php echo base_url('rekap') ?>">
            <img height="80px" src="<?php echo base_url('assets/img/logoapron.jpeg') ?>" alt="">
            <img height="80px" src="<?= base_url('assets/img/logojayapura.jpeg') ?>" alt="">
        </a>
    </div>
    <h1>Rekap data prodi <?php echo $prodi ?> bulan <?= $bulan . ' ' . $tahun ?> </h1>

    <table border="1">
        <tr>
            <th class="no" rowspan="2">No</th>
            <th rowspan="2">Nama</th>
            <th rowspan="2">NIP</th>
            <th rowspan="2">T/P</th>
            <th rowspan="2">Jabatan</th>
            <th rowspan="2">Golongan</th>
            <th colspan="2">Jam Mengajar</th>
            <th colspan="3"><?= $bulan . ' ' . $tahun ?></th>
        </tr>
        <tr>
            <th>Teori</th>
            <th>Praktek</th>
            <th>Honor Bruto</th>
            <th>Pajak PPH 21</th>
            <th>Honor Netto</th>
        </tr>
        <?php $no = 1;
        foreach ($absen_terisi as $data) : ?>
            <tr>
                <td class="td"><?= $no ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['nama']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['nip']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['tp']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['jabatan']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['golongan']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['jam_prodi']; ?></td>
                <td class="td"><?= $global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['jam_praktek']; ?></td>
                <td class="td"><?= $global->rupiah($global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['gaji_kotor']); ?></td>
                <td class="td"><?= $global->rupiah($global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['potongan']); ?></td>
                <td class="td"><?= $global->rupiah($global->get_data_rekap($data->id_pegawai, $bulan, $tahun)['honor']); ?></td>
            </tr>
        <?php $no++;
        endforeach; ?>
    </table>


    <div class="ttd">
        <div class="kiri">
            <p class="jabatan">Kepala Bagian Administrasi Akademik</p>
            <p class="nama">Syahrir Rasyid</p>
        </div>
        <div class="kanan">
            <div class="jabatan">Pengadminitrasi Akademik</div>
            <div class="nama">Ukkasyah Lubis</div>
        </div>
    </div>
    <script type="text/javascript">
        var td = document.getElementsByClassName("td");

        for (i = 0; i < td.length; i++) {
            if (i % 22 <= 10) {
                td[i].classList.add("myblue");
            }
        }
        window.print();
    </script>
</body>

</html>