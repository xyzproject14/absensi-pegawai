// console.log("ell ganteng");

// ============= BUTTON TAMBAH DATA ================
// let tambahdata = document.getElementById("btn-tambah");
// let databaruform = document.getElementsByClassName("containerdatabaru");
// let selesai = document.getElementById("selesai");

// tambahdata.addEventListener("click", function () {
// 	alert("ell ganteng banget");
// 	databaruform.classList.add("active");
// });
// selesai.addEventListener("click", function () {
// 	databaruform.classList.remove("active");
// });

// ============= END OF BUTTON TAMBAH DATA ================

// ============= BUTTON SELESAI TAMBAH DATA ================
