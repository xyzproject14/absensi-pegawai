<!DOCTYPE html>
<html>

<head>
    <title>Variasi baris ganjil genap</title>

    <style type="text/css">
        table {
            border: 1px solid #000;
        }

        thead {
            background-color: #c0bc03;
        }

        tbody tr:nth-child(even) {
            background-color: red;
        }
    </style>

</head>

<body>

    <table>
        <thead>
            <tr>
                <td>Kolom 1</td>
                <td>Kolom 2</td>
                <td>Kolom 3</td>
                <td>Kolom 4</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Baris 1</td>
                <td>ini</td>
                <td>juga</td>
                <td>ya</td>
            </tr>
            <tr>
                <td>Baris 2</td>
                <td>ini</td>
                <td>juga</td>
                <td>ya</td>
            </tr>
            <tr>
                <td>Baris 3</td>
                <td>ini</td>
                <td>juga</td>
                <td>ya</td>
            </tr>
            <tr>
                <td>Baris 4</td>
                <td>ini</td>
                <td>juga</td>
                <td>ya</td>
            </tr>
            <tr>
                <td>Baris 5</td>
                <td>ini</td>
                <td>juga</td>
                <td>ya</td>
            </tr>

        </tbody>
</body>

</html>