var ubah = document.getElementById("ubah-absen-harian");
var body = document.getElementsByClassName("body");
var footer = document.getElementsByClassName("footer");
var header = document.getElementsByClassName("header");
var container = document.getElementsByClassName("containerdatabaru");

ubah.addEventListener("click", function () {
	// header[0].classList.remove("active");
	// body[0].classList.remove("active");
	// footer[0].classList.remove("active");
	// container[0].classList.add("active");
	console.log("ell harian");
});
